import React from 'react';
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom';

function Sidebar() {
  return (
    <div className="w-64 bg-dark-800 border-r border-dark-700 min-h-screen p-4 flex flex-col">
      <div className="text-xl font-bold text-white mb-8">DARIUS STITCH</div>
      <nav className="flex flex-col gap-2">
        <Link to="/" className="text-gray-300 hover:text-white p-2">Dashboard</Link>
        <Link to="/tasks" className="text-gray-300 hover:text-white p-2">Tasks</Link>
        <Link to="/agents" className="text-gray-300 hover:text-white p-2">Agents</Link>
      </nav>
    </div>
  );
}

function App() {
  return (
    <BrowserRouter>
      <div className="flex bg-dark-900 min-h-screen text-gray-200">
        <Sidebar />
        <main className="flex-1 p-8">
          <Routes>
            <Route path="/" element={<div>Dashboard</div>} />
            <Route path="/tasks" element={<div>Tasks</div>} />
            <Route path="/agents" element={<div>Agents</div>} />
          </Routes>
        </main>
      </div>
    </BrowserRouter>
  );
}

export default App;
